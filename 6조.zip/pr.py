from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset

dataset = load_dataset('csv', data_files='url_dataset.csv')
tokenizer = DistilBertTokenizerFast.from_pretrained("distilbert-base-uncased")

def tokenize(example):
    return tokenizer(example['url'], truncation=True, padding="max_length", max_length=128)

encoded_dataset = dataset.map(tokenize)

model = DistilBertForSequenceClassification.from_pretrained(
    "distilbert-base-uncased",
    num_labels=3,
    id2label={0:"위험",1:"주의",2:"안전"},
    label2id={"위험":0,"주의":1,"안전":2}
)

training_args = TrainingArguments(
    output_dir="./saved_model",
    evaluation_strategy="epoch",
    save_strategy="epoch",
    learning_rate=3e-5,        
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=5,         
    weight_decay=0.01,
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=encoded_dataset["train"],
    eval_dataset=encoded_dataset.get("test", encoded_dataset["train"]),
)

trainer.train()

model.save_pretrained("saved_model")
tokenizer.save_pretrained("saved_model")
