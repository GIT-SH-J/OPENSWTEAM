import torch
from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification
from urllib.parse import urlparse
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 또는 ["http://127.0.0.1:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

label_map = {"위험": 0, "주의": 1, "안전": 2}
id2label = {v: k for k, v in label_map.items()}

# 모델과 토크나이저 불러오기
model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased")
tokenizer = DistilBertTokenizerFast.from_pretrained("saved_model")
model.eval()

# 🔹 URL 전처리 함수
def preprocess_url(url: str) -> str:
    parsed = urlparse(url)
    domain = parsed.netloc
    path = parsed.path
    query = parsed.query
    return f"{domain} {path} {query}".strip()

# 🔹 예측 함수
def predict_url(url: str):
    if not url.strip():
        return None, None, None

    parsed = urlparse(url)
    if not parsed.netloc or parsed.netloc.count('.') == 0:
        return None, None, None

    try:
        processed_url = preprocess_url(url)
        inputs = tokenizer(processed_url, return_tensors="pt", truncation=True, padding="max_length", max_length=128)
        with torch.no_grad():
            outputs = model(**inputs)
            probs = torch.softmax(outputs.logits, dim=1).squeeze()
            label = torch.argmax(probs).item()
            confidence = probs[label].item()

            if confidence < 0.5:
                label_str = "⚠️ 불확실"
            else:
                label_str = {0: "🔴 위험", 1: "🟡 주의", 2: "🟢 안전"}.get(label, "알 수 없음")

            return label, confidence, label_str

    except Exception as e:
        print("예측 중 오류 발생:", e)
        return None, None, None

# 🔹 프론트엔드에서 요청할 수 있는 API 경로
class UrlRequest(BaseModel):
    url: str

@app.post("/predict")
async def predict_api(request: UrlRequest):
    label, confidence, label_str = predict_url(request.url)
    if label is None:
        return {"success": False, "message": "URL이 유효하지 않거나 분석 중 오류 발생"}
    return {
        "success": True,
        "label": label,
        "confidence": round(confidence, 4),
        "label_str": label_str
    }
